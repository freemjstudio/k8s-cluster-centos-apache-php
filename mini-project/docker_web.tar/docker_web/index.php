<?php
echo "Welcome to MySimpleWeb.<br>";
echo gethostname(), "<br>";
?>

